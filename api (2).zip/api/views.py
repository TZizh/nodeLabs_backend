from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework import status
from django.utils import timezone
from django.db.models import Count, Q

from .models import Transmission
from .serializers import TransmissionSerializer

VALID_ROLES = {"TX", "RX", "RELAY"}

@api_view(["GET"])
def health(request):
    return Response({"ok": True, "app": "api"}, status=200)

# ---------- Web UI queues TX ----------
@api_view(['POST'])
def tx_message(request):
    msg = (request.data.get('message') or "").strip()
    dev = request.data.get('device', 'WebUI')

    if not msg:
        return Response({'error': 'Message cannot be empty'}, status=status.HTTP_400_BAD_REQUEST)

    tx = Transmission.objects.create(
        device=dev, role='TX', message=msg, status='PENDING'
    )
    return Response({'status': 'ok', 'id': tx.id, 'message': 'Message queued for transmission'}, status=201)

# ---------- ESP32 TX pulls one pending ----------
@api_view(['GET'])
def tx_pending(request):
    pending = (Transmission.objects.filter(role='TX', status='PENDING')
               .order_by('timestamp').first())
    if not pending:
        return Response({'status': 'no_messages', 'message': None}, status=200)

    return Response({
        'id': pending.id,
        'message': pending.message,
        'timestamp': pending.timestamp.isoformat() if pending.timestamp else None,
    }, status=200)

# ---------- ESP32 TX marks sent ----------
@api_view(['POST'])
def tx_sent(request):
    msg_id = request.data.get('id')
    device = request.data.get('device', 'TX001')

    if not msg_id:
        return Response({'error': 'Message ID required'}, status=400)

    try:
        tx = Transmission.objects.get(id=msg_id, role='TX')
    except Transmission.DoesNotExist:
        return Response({'error': f'Message ID {msg_id} not found'}, status=404)

    tx.status = 'SENT'
    tx.sent_at = timezone.now()
    tx.device = device
    tx.save()

    return Response({'status': 'ok', 'message': f'Message #{msg_id} marked as sent'}, status=200)

# ---------- ESP32 RX posts received ----------
@api_view(['POST'])
def rx_message(request):
    msg = (request.data.get('message') or "").strip()
    dev = request.data.get('device', 'RX001')
    msg_id = request.data.get('msg_id')

    if not msg:
        return Response({'error': 'Message cannot be empty'}, status=400)

    rx = Transmission.objects.create(
        device=dev, role='RX', message=msg,
        msg_id=msg_id, status='RECEIVED', received_at=timezone.now()
    )

    return Response({'status': 'ok', 'id': rx.id, 'message': 'Message received and logged'}, status=201)

# ---------- List recent messages ----------
@api_view(['GET'])
def list_messages(request):
    role = request.query_params.get('role')
    status_filter = request.query_params.get('status')

    raw_limit = request.query_params.get('limit', 50)
    try:
        limit = int(raw_limit)
    except (TypeError, ValueError):
        limit = 50
    limit = max(1, min(limit, 500))

    try:
        qs = Transmission.objects.all()

        if role:
            r = role.upper().strip()
            if r in VALID_ROLES:
                qs = qs.filter(role=r)

        if status_filter:
            qs = qs.filter(status=str(status_filter).upper().strip())

        qs = qs.order_by('-timestamp')[:limit]
        data = TransmissionSerializer(qs, many=True).data
        return Response(data, status=200)

    except Exception as e:
        return Response({'detail': f'messages endpoint error: {str(e)}'}, status=400)

# ---------- Stats for dashboards ----------
@api_view(['GET'])
def stats(request):
    try:
        today = timezone.now().date()
        qs = Transmission.objects.all()

        total_messages = qs.count()
        sent_today = qs.filter(role='TX', timestamp__date=today).count()
        received_today = qs.filter(role='RX', timestamp__date=today).count()

        pending_tx = qs.filter(role='TX').filter(
            Q(status='PENDING') | Q(status__isnull=True)
        ).count()

        by_role = dict(qs.values('role').annotate(count=Count('id')).values_list('role', 'count'))
        by_status = dict(qs.values('status').annotate(count=Count('id')).values_list('status', 'count'))

        return Response({
            'total_messages': total_messages,
            'sent_today': sent_today,
            'received_today': received_today,
            'pending_tx': pending_tx,
            'by_role': by_role,
            'by_status': by_status,
        }, status=200)

    except Exception as e:
        return Response({'detail': f'stats endpoint error: {str(e)}'}, status=400)
