
# API App Patch — Repeater Integration

Copy these over your existing `api` app (make backups first):
- models.py
- serializers.py
- views.py
- urls.py

Then run:
```
python manage.py makemigrations
python manage.py migrate
```

See README_PATCH.md in the zip for curl tests.
